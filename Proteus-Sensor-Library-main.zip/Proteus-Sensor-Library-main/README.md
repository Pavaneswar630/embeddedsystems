# Proteus-Sensor-Library
 Sensors library for proteus simulation software
